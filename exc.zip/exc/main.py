import executable


window = executable.Terminal('sdd')
window.run()