class FileManager:
    def __init__(self):
        self.data: list[str] = []

    def append(self,data: str) -> list[str]:
        self.data.append(str(data))
        return self.data
    
    def pop(self,index: int = -1) -> list[str]:
        self.data.pop(index)
        return self.data
    
    def list(self) -> None:
        print(*self.data,sep='\n')