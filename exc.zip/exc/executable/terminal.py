from sys import exit
from os import system as terminal
import colorama
import time
import os

from .file_manager import FileManager
from .code_editor import CodeEditor


def exit_code(name: str, id: str) -> str:
    return colorama.Fore.LIGHTRED_EX+f'\n<error_code:'+colorama.Style.BRIGHT+f'\'{name}\'={id}'+colorama.Style.RESET_ALL+colorama.Fore.LIGHTRED_EX+'>'+ colorama.Fore.RESET

def exit_program() -> None:
    time.sleep(5)
    for i in ["▓","▓▓","▓▓▓","▓▓▓▓","▓▓▓▓▓"]:
        terminal('cls')
        print(colorama.Fore.LIGHTBLACK_EX + f"exiting[{i:<5}]" + colorama.Style.RESET_ALL)    
        time.sleep(len(i)/(2*2))
    print(colorama.Fore.LIGHTBLACK_EX + f"exiting succussful!" + colorama.Style.RESET_ALL)
    time.sleep(1)
    terminal('cls')

class Terminal:
    def __init__(self,name: str):
        self._user: str = name
        self._file: FileManager
        self._path: str = os.getcwd()
        self._commands: dict[int:list[str,list[str]]] = {
            0:['ls',['-a']],
            1:['mk',[]],
            2:['exit',[]],
            3:['run',['-exc','-py']],
            4:['delete',['-num','-nam']],
            5:['help',['-exit']],
            6:['ter',[]],
            7:['clear',[]]
        }
        self._exit_codes: dict[str:str] = {
        '01':'InProcess',
        '02':'InvalidCode',
        '00':'Exit',
        }

    def _terminal(self):
        while True:
            _code: str = input(f'S {os.getcwd()}>')
            terminal(_code)

            if _code == 'exit': break

    def run(self):
        print(f"hello {self._user}!\nwelcome to executable")
        while True:
            try:
                _code: list[str] = input('['+colorama.Fore.LIGHTMAGENTA_EX+f'{self._user}'+colorama.Fore.RESET+colorama.Fore.LIGHTYELLOW_EX+f'@{os.getcwd()}'+colorama.Fore.RESET+']>>').split(' ')
                print(colorama.Fore.RESET)

                if   _code[0] == '': continue
                elif _code[0] == self._commands[0][0]: exit_code('InvalidCode','0202')
                elif _code[0] == self._commands[0][0] and _code[1] == self._commands[0][0]: self._file.list()

                elif _code[0] == self._commands[1][0]: CodeEditor.run()

                elif _code[0] == self._commands[5][0]: exit_code('InvalidCode','0201')
                elif _code[0] == self._commands[5][0] and _code[1] == self._commands[4][1]: exit_code('InProcess[delete -nam]','0101')
                elif _code[0] == self._commands[5][0] and _code[1] == self._commands[4][0]: self._file.pop(int(_code[2]))

                elif _code[0] == self._commands[1][0]: print(exit_code('Inprocess[mk]','0100'))
                elif _code[0] == self._commands[1][0] and _code[1] == self._commands[1][0]: print(exit_code('InProcess[mk]','0100'))
                elif _code[0] == self._commands[1][0] and _code[1] == self._commands[1][1]: print(exit_code('InProcess[mk]','0100'))
                
                elif _code[0] == self._commands[5][0]: 
                    print(f'Commands')
                    for i in self._commands.values():
                        for i1 in i:
                            for i2 in i1:
                                pass
                        print(f'{i[0]}:\t{i1}')
                    print(f'\nExitCodes')
                    for id,name in self._exit_codes.items():
                        print(f'{id}:\t{name}')

                elif _code[0] == self._commands[6][0]: self._terminal()

                elif _code[0] == self._commands[7][0]: terminal('cls')

                elif _code[0] == self._commands[2][0]: print(exit_code('Exit[UserExit]','0001'));exit_program();break

                else: print(exit_code('InvalidCode', '0200'))
            except KeyboardInterrupt as e:
                print(exit_code('Exit[KeyboardInterrupt]','0000'))
                exit()


if __name__ == "__main__":
    window = Terminal("Veera")
    window.run()